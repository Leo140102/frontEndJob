import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './PokemonData.css';

const PokemonData = () => {
  const [pokemonList, setPokemonList] = useState([]);
  const [selectedPokemon, setSelectedPokemon] = useState(null);

  useEffect(() => {
    async function fetchPokemonList() {
      try {
        const response = await axios.get('https://pokeapi.co/api/v2/pokemon?limit=20');
        const data = response.data.results;
        setPokemonList(data);
      } catch (error) {
        console.log(error);
      }
    }

    fetchPokemonList();
  }, []);

  const fetchPokemonDetails = async (pokemon) => {
    try {
      const response = await axios.get(pokemon.url);
      const data = response.data;
      setSelectedPokemon(data);
    } catch (error) {
      console.log(error);
    }
  };

  const handlePokemonClick = (pokemon) => {
    fetchPokemonDetails(pokemon);
  };

  return (
    <div className="pokemon-data-container">
      <h1>
        Pokedex
      </h1>
      <div className="pokemon-list-container">
        {pokemonList.map((pokemon) => (
          <div
            className={`pokemon-item ${selectedPokemon === pokemon ? 'active' : ''}`}
            key={pokemon.name}
            onClick={() => handlePokemonClick(pokemon)}
          >
            <img
              src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${pokemon.url.split('/')[6]}.png`}
              alt={pokemon.name}
            />
            <h2>{pokemon.name}</h2>
            <Link to={`/pokemon/${pokemon.name}`}>Ver detalhes</Link>
          </div>
        ))}
      </div>

      {selectedPokemon && (
        <div className="pokemon-details">
          <h2>{selectedPokemon.name}</h2>
          <p>Height: {selectedPokemon.height}</p>
          <p>Weight: {selectedPokemon.weight}</p>
          <p>Abilities:</p>
          <ul>
            {selectedPokemon.abilities.map((ability) => (
              <li key={ability.ability.name}>{ability.ability.name}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default PokemonData;
